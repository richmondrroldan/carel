<?php
    // Include Files
    require_once 'classes/config.php';
    require_once 'classes/tools.php';

    $isGuestOk = 1;

    $tools = new Tools();

    $events = $tools->viewAllQry('SELECT * FROM events where available_attendees > 0');

    // dd($events);
?>
<!doctype html>
<html lang="en">
    <head>
        <?php $isGuestOk = 1; include 'layouts/head.php';?>
    </head>
    <body>

        <!-- <header>
            <div class="navbar navbar-dark bg-dark shadow-sm">
                <div class="container d-flex justify-content-between">
                    <a href="#" class="navbar-brand d-flex align-items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>
                        <strong>Events</strong>
                    </a>
                </div>
            </div>
        </header> -->
        <header>
            <?php include 'layouts/header.php';?>
        </header>





















        <main role="main">

            <!-- banner -->
            <section id="banner">
                <div class="container-60">
                    <span class="content">
                        <h1>Curating Local Art Experience</h1>
                    </span>
                </div>

                <!-- photos -->
                <div class="assets">
                    <img src="images/hand-left.png" id="left-hand">
                    <img src="images/hand-right.png" id="right-hand">
                    <img src="images/city.png" alt="" id="city">
                </div>
            </section>

            <!-- <section id="banner" class="jumbotron text-center">
                <div class="container">
                    <h1 class="jumbotron-heading"><strong>Events</strong></h1>
                    <p class="lead text-muted">
                        <strong>REGISTER | JOIN | HAVE FUN</strong>
                    </p>
                        <br>
                    <p class="text-muted">Want to be one of us and be able to post an event?</p>
                    <p>
                        <a href="register.php" class="btn btn-primary my-2">Join Us!</a>
                    </p>
                </div>
            </section> -->










            <!-- about -->
            <section id="about">
                <div class="container">
                    <article class="one-half">
                        <p>hide</p>
                        <img src="images/home-about-1.png" id="about-asset-1">
                        <img src="images/home-about-2.png" id="about-asset-2">
                    </article>
                    <article class="one-half">
                        <h3>Bringing the arts and culture to you more closely</h3>
                        <p>Art Locale provides you updates about different events in Benilde and other local independent events</p>
                    </article>
                </div>
            </section>





            <section id="about-2">
                <div class="container">
                    <article class="one-half">
                        <h3>Deaf friendly feature</h3>
                        <p>As an advocate of inclusion, Art Locale provides a feature for the deaf community. We make sure that the website provides information if an event is providing an Filipino Sign Language (FSL) translator.</p>
                    </article>
                    <article class="one-half">
                        <img src="images/ear.png" id="ear">
                    </article>
                </div>
            </section>










            <!-- upcoming events -->
            <section id="upcoming">
                <div class="container">
                    <h2>Upcoming Events</h2>
                    <a href="">
                        <button class="primary">View More Events</button>
                    </a>
                </div>
            </section>










            <!-- media partnership -->
            <section id="partnership">
                <div class="container-60">
                    <h2>Have an upcoming event? Partner with us.</h2>
                    <p>Art Locale provides media partnership for different events in Benilde and other local independent productions within Metro Manila</p>
                    <a href="">
                        <button class="primary">Become a Partner</button>
                    </a>
                </div>
            </section>











            <!-- event thumbnails -->

            <!-- <div class="album py-5 bg-light">
                <div class="container">
                    <?php if(!empty($_GET['register'])):?>
                        <?php if($_GET['register'] == 'success'):?>
                            <div class="alert alert-success">
                                <p>You have successfully joined in the event!</p>
                            </div>
                        <?php elseif($_GET['register'] == 'user'):?>
                            <div class="alert alert-success">
                                <p>
                                    You have successfully registered as an event coordinator!
                                    You may now login in this <a href="admin">link</a>.
                                </p>
                            </div>
                        <?php elseif($_GET['register'] == 'error'):?>
                            <div class="alert alert-danger">
                                <p>Something went wrong!</p>
                            </div>
                        <?php endif?>
                    <?php endif?>
                    <div class="row">
                        <?php foreach($events as $key => $event):?>
                            <div class="col-md-4">
                                <div class="card mb-4 shadow-sm">
                                    <img class="card-img-top" src="images/default.png" alt="Card image cap">
                                    <div class="card-body">
                                        <p><?= $event['name']?></p>
                                        <p class="card-text text-justify"><?= $event['description']?>.</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <a href="event_register.php?eventid=<?=$event['id']?>" class="btn btn-sm btn-outline-primary">Register</a>
                                            <small class="text-muted"><?php echo date('M d, Y',strtotime($event['event_date']));?></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach;?>
                    </div>
                </div>
            </div> -->
        </main>

        <?php include 'layouts/footer.php';?>
    </body>
</html>
