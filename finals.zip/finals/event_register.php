<?php
// Include Files
require_once 'classes/config.php';
require_once 'classes/tools.php';

$eventId = $_GET["eventid"];
if(empty($eventId)){
    header("Location: index.php");
}

$tools = new Tools();

$event = $tools->view('events',$eventId);

if(!$event || $event['available_attendees'] < 0){
    header("Location: index.php");
}

// Define variables and initialize with empty values
$fullname = $email = $gender = $age = $address = "";
$fullname_err = $email_err = $gender_err = $age_err = $address_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    $tools->trimAllData();
    
    $fullname   = ($_POST['fullname'])      ? $_POST['fullname']: NULL ;
    $email      = ($_POST['email'])         ? $_POST['email']   : NULL ;
    $gender     = ($_POST['gender'])        ? $_POST['gender']  : NULL ;
    $age        = (isset($_POST['age']))    ? $_POST['age']     : NULL ;
    $address    = ($_POST['address'])       ? $_POST['address'] : NULL ;
    $event_id   = ($_POST['event_id'])      ? $_POST['event_id'] : NULL ;

    // Validate fullname
    if(empty($_POST['fullname'])){
        $fullname_err = "Please enter your full name.";     
    } elseif(strlen($_POST['fullname']) > 255){
        $fullname_err = "Full Name must have atleast 255 characters.";
    }

    // Validate email
    if(empty($_POST['email'])){
        $password_err = "Please enter your email.";     
    } elseif(strlen($_POST['email']) > 100){
        $password_err = "Email must have atleast 100 characters.";
    }

    // Validate gender
    if(empty($_POST['gender'])){
        $gender_err = "Please select your gender.";     
    }

    // Validate age
    if(!isset($_POST['age'])){
        $age_err = "Please enter your age.";     
    } elseif(!is_numeric($_POST['age']) || $_POST['age'] <= 0){
        $age_err = "Invalid age value.";
    }

    // Validate address
    if(empty($_POST['address'])){
        $address_err = "Please enter your address.";     
    }

    // Check input errors before inserting in database
    if(empty($fullname_err) && empty($email_err) && empty($gender_err)
        && empty($age_err) && empty($address_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO attendees (full_name, email, gender, age, address, event_id) VALUES (?, ?, ?, ?, ?, ?)";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssisi", $fullname, 
                                                    $email, 
                                                    $gender, 
                                                    $age, 
                                                    $address, 
                                                    $event_id);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $sql = "UPDATE events SET available_attendees=available_attendees-1 WHERE id=?";
                if($stmt2 = mysqli_prepare($link, $sql)){

                    // Bind variables to the prepared statement as parameters
                    mysqli_stmt_bind_param($stmt2, "i",  $event_id);   
                }
                if(mysqli_stmt_execute($stmt2)){
                    // Redirect to index page
                    header("Location: index.php?register=success");
                }
                
            } else{
                header("Location: index.php?register=error");
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
<!doctype html>
<html lang="en">
    <head>
        <?php $isGuestOk = 1; include 'layouts/head.php';?>
        <link href="css/floating-labels.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/styles.css">
        <style>
            body{
                background: url(https://images.pexels.com/photos/1020323/pexels-photo-1020323.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260);
            }
        </style>
    </head>

    <body>
        <div class="form-signin">
            <div class="text-center mb-4">
                <h1>Event Details</h1>
            </div>
            <div class="form-label-group <?php echo (!empty($fullname_err)) ? 'has-danger' : ''; ?>">
                <input type="text" id="event_name" name="event_name" class="form-control" value="<?php echo htmlspecialchars($event['name']); ?>" readonly>
                <label for="event_name">Event Name</label>
            </div>
            <div class="form-label-group <?php echo (!empty($fullname_err)) ? 'has-danger' : ''; ?>">
                <input type="text" id="description" name="description" class="form-control" value="<?php echo htmlspecialchars($event['description']); ?>" readonly>
                <label for="description">Event Description</label>
            </div>
            <div class="form-label-group <?php echo (!empty($fullname_err)) ? 'has-danger' : ''; ?>">
                <input type="text" id="slots" name="slots" class="form-control" placeholder="Full Name" value="<?php echo htmlspecialchars($event['available_attendees']); ?>" readonly>
                <label for="slots">Remaining Slot/s</label>
            </div>            
        </div>
        
        <form class="form-signin" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?eventid=<?=$event['id']?>" method="post">
            <div class="text-center mb-4">
                <h1>Register</h1>
            </div>
            <input type="hidden" name="event_id" class="form-control" value="<?=$event['id']?>">
            <div class="form-label-group <?php echo (!empty($fullname_err)) ? 'has-danger' : ''; ?>">
                <input type="text" id="fullname" name="fullname" class="form-control" placeholder="Full Name" value="<?php echo $fullname; ?>" required>
                <label for="fullname">Full Name</label>
                <span class="help-block"><?php echo $fullname_err; ?></span>
            </div>

            <div class="form-label-group <?php echo (!empty($email_err)) ? 'has-danger' : ''; ?>">
                <input type="email" id="email" name="email" class="form-control" placeholder="Email Address" value="<?php echo $email; ?>" required>
                <label for="email">Email address</label>
                <span class="help-block"><?php echo $email_err; ?></span>
            </div>
            <div class="form-label-group <?php echo (!empty($gender_err)) ? 'has-danger' : ''; ?>">
                <select class="form-control" name="gender" required>
                    <option value="" <?php if(empty($gender)) echo "selected"; ?>>Please Select Gender</option>
                    <option value="M" <?php if(!empty($gender) && $gender == 'M') echo "selected"; ?>>Male</option>
                    <option value="F" <?php if(!empty($gender) && $gender == 'F') echo "selected"; ?>>Female</option>                        
                </select>
                <span class="help-block"><?php echo $gender_err; ?></span>
            </div>
            <div class="form-label-group <?php echo (!empty($age_err)) ? 'has-danger' : ''; ?>">
                <input type="text" id="age" name="age" class="form-control" value="<?php echo $age; ?>" placeholder="Enter Age" required>
                <label for="age">Age</label>
                <span class="help-block"><?php echo $age_err; ?></span>
            </div>
            <div class="form-label-group <?php echo (!empty($address_err)) ? 'has-danger' : ''; ?>">
                <input type="text" id="address" name="address" class="form-control" value="<?php echo $address; ?>" placeholder="Enter Address" required>
                <label for="address">Address</label>
                <span class="help-block"><?php echo $address_err; ?></span>
            </div>
            
            <br>

            <a href="index.php" class="btn btn-primary">Back</a>
            <button class="btn btn-success" type="submit">Submit</button>
        </form>
    </body>
</html>
