<?php
// Include Files
require_once 'classes/config.php';
require_once 'classes/tools.php';
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $tools = new Tools();
    $tools->trimAllData();

    $username           = ($_POST['username'])          ? $_POST['username']        : NULL ;
    $password           = ($_POST['password'])          ? $_POST['password']        : NULL ;
    $confirm_password   = ($_POST['confirm_password'])  ? $_POST['confirm_password']: NULL ;

    // Validate username
    if(empty($_POST["username"])){
        $username_err = "Please enter a username.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $username);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                }
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate password
    if(empty($_POST['password'])){
        $password_err = "Please enter a password.";     
    } elseif(strlen($_POST['password']) < 6){
        $password_err = "Password must have atleast 6 characters.";
    }
    
    // Validate confirm password
    if(empty($_POST["confirm_password"])){
        $confirm_password_err = 'Please confirm password.';     
    } else{
        if($password != $confirm_password){
            $confirm_password_err = 'Password did not match.';
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password,is_admin,is_active) VALUES (?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssii", $username, 
                                                    $password, 
                                                    $is_admin, 
                                                    $is_active);
            
            // Set parameters
            $password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $is_admin = 0;
            $is_active = 1;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: index.php?register=user");
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
<!doctype html>
<html lang="en">
    <head>
        <?php $isGuestOk = 1; include 'layouts/head.php';?>
        <link href="css/floating-labels.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/styles.css">
        <style>
            body{
                background: url(https://images.pexels.com/photos/1020323/pexels-photo-1020323.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260);
            }
        </style>
    </head>

    <body>        
        <form class="form-signin" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="text-center mb-4">
                <h1>Join Us</h1>
            </div>
            <div class="form-label-group <?php echo (!empty($username_err)) ? 'has-danger' : ''; ?>">
                <input type="text" id="username" name="username" class="form-control" value="<?php echo $username; ?>" placeholder="Enter Username" required>
                <label for="username">Username</label>
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>
            <div class="form-label-group <?php echo (!empty($password_err)) ? 'has-danger' : ''; ?>">
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter Password" required>
                <label for="password">Password</label>
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-label-group <?php echo (!empty($confirm_password_err)) ? 'has-danger' : ''; ?>">
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Enter Confirm Password" required>
                <label for="confirm_password">Confirm Password</label>
                <span class="help-block"><?php echo $confirm_password_err; ?></span>
            </div>            
            <br>

            <a href="index.php" class="btn btn-primary">Back</a>
            <button class="btn btn-success" type="submit">Submit</button>
        </form>
    </body>
</html>
