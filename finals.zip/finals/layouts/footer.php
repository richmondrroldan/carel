<!-- FOOTER -->
<footer>
	<div class="container">
		<article class="one-half">
			<h3>Art Locale</h3>
			<p>Curating Local Art Experience</p>
		</article>

		<!-- accounts -->
		<article class="one-half">
			<nav>
				<ul>
					<a href="https://www.facebook.com/artlocaleph"><li>
						<img src="images/icons/facebook.png">
					</li></a>
					<a href="https://www.messenger.com/t/artlocaleph"><li>
						<img src="images/icons/messenger.png">
					</li></a>
					<a href="http://instagram.com/artlocaleph"><li>
						<img src="images/icons/instagram.png">
					</li></a>
					<a href="mailto:artlocaleph@gmail.com"><li>
						<img src="images/icons/mail.png">
					</li></a>
				</ul>
			</nav>
		</article>

		<!-- copyright -->
		<article class="one-whole">
			<p>© Art Locale PH and ca | For educational purposes only</p>
		</article>
	</div>
</footer>


<!-- scripts -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
