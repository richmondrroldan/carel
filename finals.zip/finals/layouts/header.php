			<div class="container-wide">
                <!-- logo -->
                <span id="logo">
                    <a href="index.php"><img src="images/logo.png"></a>
                </span>

                <!-- navigation -->
                <nav>
                    <ul>
                        <a href="index.php"><li>Home</li></a>
                        <a href="events.php"><li>Events</li></a>
                        <a href="help.php"><li>Help</li></a>
                    </ul>
                </nav>
            </div>