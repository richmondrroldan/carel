<?php
// Include Files
require_once '../classes/config.php';
require_once '../classes/tools.php';

$userId = $_GET["id"];
if(empty($userId)){
    header("Location: dashboard.php");
}

$tools = new Tools();

$user = $tools->view('users',$userId);

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $isGuestOk = 0; include 'layouts/head.php';?>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <?php include 'layouts/navbar.php';?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="page-header">
                        <h2>View User</h2>
                    </div>
                    <div class="margin-bottom-50">
                        <div class="form-group">
                            <label>User Name</label>
                            <input type="text" name="username" class="form-control" value="<?php echo $user['username']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>User Type</label>
                            <select class="form-control" name="type" readonly>
                                <option value="1" <?php if($user['is_admin'] == 1) echo "selected"; ?>>Admin</option>
                                <option value="0" <?php if($user['is_admin'] == 0) echo "selected"; ?>>Event Coordinator</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>User Type</label>
                            <select class="form-control" name="type" readonly>
                                <option value="1" <?php if($user['is_active'] == 1) echo "selected"; ?>>Active</option>
                                <option value="0" <?php if($user['is_active'] == 0) echo "selected"; ?>>In-Active</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Date Created</label>
                            <input type="text" name="date_created" class="form-control" value="<?php echo date('M d, Y',strtotime($user['created_at']));?>"readonly>
                        </div>
                        <a href="view_all_users.php" class="btn btn-primary">Back</a>
                    </div>
                </div>
            </div>        
        </div>
    </div>
    <?php include 'layouts/footer.php';?>
</body>
</html>