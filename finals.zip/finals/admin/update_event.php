<?php
// Include Files
require_once '../classes/config.php';
require_once '../classes/tools.php';

$eventId = $_GET["id"];
if(empty($eventId)){
    header("Location: dashboard.php");
}

$tools = new Tools();

$event = $tools->view('events',$eventId);
 
// Define variables and initialize with empty values
$name = $description = $slots = "";
$name_err = $description_err = $slots_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $tools = new Tools();
    $tools->trimAllData();

    // Validate name
    if(empty($_POST['name'])){
        $name_err = "Please enter event name.";     
    } elseif(strlen($_POST['name']) > 255){
        $name_err = "Name must have atleast 255 characters.";
    }

    // Validate description
    if(empty($_POST['description'])){
        $description_err = "Please enter description.";     
    } elseif(strlen($_POST['description']) > 255){
        $description_err = "Description must have atleast 255 characters.";
    }

    // Validate slots
    if(empty($_POST['slots'])){
        $slots_err = "Please enter No. of available slot.";     
    } elseif(!is_numeric($_POST['slots']) || $_POST['slots'] <= 0){
        $slots_err = "Invalid slot value.";
    }

    $name           = $_POST['name'];
    $description    = $_POST['description'];
    $slots          = $_POST['slots'];
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($description_err) && empty($slots_err)){    
        // Prepare an insert statement
        $sql = "UPDATE events set name=?, description=?, available_attendees=? where id=?";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssii", $param_name, $param_description, $param_slots,$param_id);
            
            // Set parameters
            $param_name         = $name;
            $param_description  = $description;
            $param_slots        = $slots;
            $param_id           = $eventId;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: view_all_events.php?action=update");
            } else{
                header("location: view_all_events.php?action=error");
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $isGuestOk = 0; include 'layouts/head.php';?>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <?php include 'layouts/navbar.php';?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="page-header">
                        <h2>Update Event</h2>
                    </div>

                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?= $event['id']?>" method="post" class="margin-bottom-50">
                        <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($event['name']); ?>" required>
                            <span class="help-block"><?php echo $name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($description_err)) ? 'has-error' : ''; ?>">
                            <label>Description</label>
                            <input type="text" name="description" class="form-control" value="<?php echo htmlspecialchars($event['description']); ?>" required>
                            <span class="help-block"><?php echo $description_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($slots_err)) ? 'has-error' : ''; ?>">
                            <label>No. of Available Slots</label>
                            <input type="text" name="slots" class="form-control" value="<?php echo $event['available_attendees']; ?>" required>
                            <span class="help-block"><?php echo $slots_err;?></span>
                        </div>
                        <div class="form-group">
                            <label>Date of Event</label>
                            <input type="text" name="event_date" class="form-control" value="<?php echo date('M d, Y',strtotime($event['event_date']));?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Created By</label>
                            <input type="text" name="event_date" class="form-control" value="<?php echo $event['created_by']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Created Date</label>
                            <input type="text" name="event_date" class="form-control" value="<?php echo date('M d, Y',strtotime($event['created_at']));?>" readonly>
                        </div>
                        <input type="submit" class="btn btn-success" value="Submit">
                        <a href="view_all_events.php" class="btn btn-default">Back</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
    <?php include 'layouts/footer.php';?>
</body>
</html>