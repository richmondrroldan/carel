<?php
// Include Files
require_once '../classes/config.php';
require_once '../classes/tools.php';

$userId = $_GET["id"];
if(empty($userId)){
    header("Location: dashboard.php");
}

$tools = new Tools();

$user = $tools->view('users',$userId);

// Define variables and initialize with empty values
$username = $status = $type = "";
$username_err = $status_err = $type_err = $id_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $tools = new Tools();
    $tools->trimAllData();
    
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    }

    // Validate User Id
    if(empty($_POST['id'])){
        $id_err = "ID is required.";     
    }
    
    // Validate User Type
    if(!isset($_POST['type'])){
        $type_err = "Please Select User Type.";     
    }

    // Validate User Status
    if(!isset($_POST['status'])){
        $status_err = "Please Select User Type.";     
    }

    $id             = $_POST['id'];
    $username       = $_POST['username'];
    $type           = $_POST['type'];
    $status         = $_POST['status'];

    // Check input errors before inserting in database
    if(empty($username_err) && empty($status_err) && empty($type_err) && empty($id_err)){    

        // Prepare an insert statement
        $sql = "UPDATE users SET username=?, is_admin=? ,is_active=? WHERE id=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "siii", $param_username,$param_is_admin,$param_is_active,$param_id);
            
            // Set parameters
            $param_username = $username;
            $param_is_admin = $type;
            $param_is_active = $status;
            $param_id = $id;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: view_all_users.php?action=update");
            } else{
                header("location: view_all_users.php?action=error");
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $isGuestOk = 0; include 'layouts/head.php';?>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <?php include 'layouts/navbar.php';?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="page-header">
                        <h2>Update User</h2>
                    </div>

                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?=$user['id']?>" method="post" class="margin-bottom-50">
                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                        <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                            <label>User Name</label>
                            <input type="text" name="username" class="form-control" value="<?php echo $user['username']; ?>" reaquired>
                            <span class="help-block"><?php echo $username_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($type_err)) ? 'has-error' : ''; ?>">
                            <label>User Type</label>
                            <select class="form-control" name="type" required>
                                <option value="1" <?php if($user['is_admin'] == 1) echo "selected"; ?>>Admin</option>
                                <option value="0" <?php if($user['is_admin'] == 0) echo "selected"; ?>>Event Coordinator</option>                        
                            </select>
                            <span class="help-block"><?php echo $type_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($status_err)) ? 'has-error' : ''; ?>">
                            <label>User Type</label>
                            <select class="form-control" name="status" required>
                                <option value="1" <?php if($user['is_active'] == 1) echo "selected"; ?>>Active</option>
                                <option value="0" <?php if($user['is_active'] == 0) echo "selected"; ?>>In-Active</option>                        
                            </select>
                            <span class="help-block"><?php echo $status_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="view_all_users.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
    <?php include 'layouts/footer.php';?>
</body>
</html>