<?php
// Include Files
require_once '../classes/config.php';
require_once '../classes/tools.php';
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = $type_err = "";
$username_err = $password_err = $confirm_password_err = $type_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $tools = new Tools();
    $tools->trimAllData();
    // dd($_POST);
    
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Validate password
    if(empty($_POST['password'])){
        $password_err = "Please enter a password.";     
    } elseif(strlen($_POST['password']) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = $_POST['password'];
    }
    
    // Validate confirm password
    if(empty($_POST["confirm_password"])){
        $confirm_password_err = 'Please confirm password.';     
    } else{
        $confirm_password = $_POST['confirm_password'];
        if($password != $confirm_password){
            $confirm_password_err = 'Password did not match.';
        }
    }

    // Validate User Type
    if(!isset($_POST['type'])){
        $type_err = "Please Select User Type.";     
    }

    $username       = $_POST['username'];
    $type           = $_POST['type'];
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($type_err)){    

        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password,is_admin,is_active) VALUES (?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssii", $param_username, $param_password,$param_is_admin,$param_is_active);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_is_admin = $type;
            $param_is_active = 1;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: view_all_users.php?action=success");
            } else{
                header("location: view_all_users.php?action=error");
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $isGuestOk = 0; include 'layouts/head.php';?>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <?php include 'layouts/navbar.php';?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="page-header">
                        <h2>Create User</h2>
                    </div>

                    <p>Please fill this form and submit to add a user record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="margin-bottom-50">
                        <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                            <label>User Name</label>
                            <input type="text" name="username" class="form-control" value="<?php echo $username; ?>" required>
                            <span class="help-block"><?php echo $username_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                            <span class="help-block"><?php echo $password_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
                            <label>Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                            <span class="help-block"><?php echo $confirm_password_err;?></span>
                        </div>
                        
                        <div class="form-group <?php echo (!empty($type_err)) ? 'has-error' : ''; ?>">
                            <label>User Type</label>
                            <select class="form-control" name="type" required>
                                <option value="" <?php if(empty($type)) echo "selected"; ?>>Please Select User Type</option>
                                <option value="1" <?php if(!empty($type) && $type == '1') echo "selected"; ?>>Admin</option>
                                <option value="0" <?php if(!empty($type) && $type == '0') echo "selected"; ?>>Event Coordinator</option>                        
                            </select>
                            <span class="help-block"><?php echo $type_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="dashboard.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
    <?php include 'layouts/footer.php';?>
</body>
</html>