<?php
// Include Files
require_once '../classes/config.php';
require_once '../classes/tools.php';

    $tools = new Tools();

    $users = $tools->viewAll('users');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php $isGuestOk=0; include 'layouts/head.php';?>
    </head>
    <body>
        <?php include 'layouts/navbar.php';?>
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1">
                        <?php if(!empty($_GET['action'])):?>
                            <?php if($_GET['action'] == 'success'):?>
                                <div class="alert alert-success">
                                    <p>You have successfully created a user!</p>
                                </div>
                            <?php elseif($_GET['action'] == 'update'):?>
                                <div class="alert alert-success">
                                    <p>You have successfully updated a user!</p>
                                </div>
                            <?php elseif($_GET['action'] == 'delete'):?>
                                <div class="alert alert-success">
                                    <p>You have successfully deleted a user!</p>
                                </div>
                            <?php elseif($_GET['action'] == 'error'):?>
                                <div class="alert alert-danger">
                                    <p>Something went wrong!</p>
                                </div>
                            <?php endif?>
                        <?php endif?> 
                        <div class="page-header clearfix">
                            <h2 class="pull-left">View All Users</h2>
                            <a href="create_user.php" class="btn btn-success pull-right">Add New User</a>
                        </div>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User Name</th>
                                    <th>User Type</th>
                                    <th>Status</th>
                                    <th>Date Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($users):?>
                                    <?php foreach($users as $key => $user):?>
                                        <tr>
                                            <td><?= $user['id']?></td>
                                            <td><?= htmlspecialchars($user['username'])?></td>
                                            <td><?php echo ($user['is_admin']) ? "Admin" : "Event Coordinator";?></td>
                                            <td><?php echo ($user['is_active']) ? "Active" : "In-Active";?></td>
                                            <td><?php echo date('M d, Y',strtotime($user['created_at']));?></td>
                                            <td>
                                                <a href="read_user.php?id=<?= $user['id']?>" title="View Record" data-toggle="tooltip">
                                                    <span class='glyphicon glyphicon-eye-open'></span>
                                                </a>
                                                <a href="update_user.php?id=<?= $user['id']?>" title="Update Record" data-toggle="tooltip">
                                                    <span class='glyphicon glyphicon-pencil'></span>
                                                </a>
                                                <a href="delete_user.php?id=<?= $user['id']?>" title="Delete Record" data-toggle="tooltip">
                                                    <span class='glyphicon glyphicon-trash'></span>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach;?>
                                <?php else:?>
                                    <tr>
                                        <td colspan="6" class="center">
                                            No records found.
                                        </td>
                                    </tr>
                                <?php endif;?>
                            </tbody>
                        </table>
                    </div>
                </div>        
            </div>
        </div>
        <?php include 'layouts/footer.php';?>
    </body>
</html>