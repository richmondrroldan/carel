<?php
// Include Files
require_once '../classes/config.php';
require_once '../classes/tools.php';

$eventId = $_GET["id"];
if(empty($eventId)){
    header("Location: dashboard.php");
}

$tools = new Tools();

$event      = $tools->view('events',$eventId);
$attendees  = $tools->viewAllQry('SELECT * FROM attendees where event_id='.$eventId);

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $isGuestOk = 0; include 'layouts/head.php';?>
    <style type="text/css">
        .wrapper{
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <?php include 'layouts/navbar.php';?>
    <div class="wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="page-header">
                        <h2>View Event</h2>
                    </div>

                    <div class="margin-bottom-50">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $event['name']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <input type="text" name="description" class="form-control" value="<?php echo $event['description']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>No. of Available Slots</label>
                            <input type="text" name="slots" class="form-control" value="<?php echo $event['available_attendees']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Date of Event</label>
                            <input type="text" name="event_date" class="form-control" value="<?php echo date('M d, Y',strtotime($event['event_date']));?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Created By</label>
                            <input type="text" name="event_date" class="form-control" value="<?php echo $event['created_by']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Created Date</label>
                            <input type="text" name="event_date" class="form-control" value="<?php echo date('M d, Y',strtotime($event['created_at']));?>" readonly>
                        </div>
                        <a href="view_all_events.php" class="btn btn-primary">Back</a>
                    </div>
                </div>
                <div class="col-md-5 col-md-offset-1">
                    
                    <div class="page-header">
                        <h2>View All Attendees</h2>
                    </div>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Gender</th>
                                <th>Age</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($attendees):?>
                                <?php foreach($attendees as $key => $attendee):?>
                                    <tr>
                                        <td><?= htmlspecialchars($attendee['full_name'])?></td>
                                        <td><?= htmlspecialchars($attendee['email'])?></td>
                                        <td><?php echo ($attendee['gender'] == "M") ? "Male" : "Female";?></td>
                                        <td><?= htmlspecialchars($attendee['age'])?></td>
                                    </tr>
                                <?php endforeach;?>
                            <?php else:?>
                                <tr>
                                    <td colspan="4" class="center">
                                        No records found.
                                    </td>
                                </tr>
                            <?php endif;?>
                        </tbody>
                    </table>
                </div>
            </div>        
        </div>
    </div>
    <?php include 'layouts/footer.php';?>
</body>
</html>