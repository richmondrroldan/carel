<?php
// Include Files
require_once '../classes/config.php';
require_once '../classes/tools.php';
 
// Define variables and initialize with empty values
$name = $description = $slots = $event_date = "";
$name_err = $description_err = $slots_err = $event_date_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $tools = new Tools();
    $tools->trimAllData();

    // Validate name
    if(empty($_POST['name'])){
        $name_err = "Please enter event name.";     
    } elseif(strlen($_POST['name']) > 255){
        $name_err = "Name must have atleast 255 characters.";
    }

    // Validate description
    if(empty($_POST['description'])){
        $description_err = "Please enter description.";     
    } elseif(strlen($_POST['description']) > 255){
        $description_err = "Description must have atleast 255 characters.";
    }

    // Validate slots
    if(empty($_POST['slots'])){
        $slots_err = "Please enter No. of available slot.";     
    } elseif(!is_numeric($_POST['slots']) || $_POST['slots'] <= 0){
        $slots_err = "Invalid slot value.";
    }

    // Validate event date
    if(empty($_POST['event_date'])){
        $event_date_err = "Please enter event date.";     
    }

    $name           = $_POST['name']        ;
    $description    = $_POST['description'] ;
    $slots          = $_POST['slots']       ;
    $event_date     = date('Y-m-d H:i:s',strtotime($_POST['event_date']))  ;
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($description_err) && empty($slots_err) && empty($event_date_err)){    
        // Prepare an insert statement
        $sql = "INSERT INTO events (name, description, available_attendees, created_by, event_date) VALUES (?, ?, ?, ?, ?)";
        if($stmt = mysqli_prepare($link, $sql)){
            session_start();
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssiss", $name, $description, $slots,$param_user,$event_date);
            
            // Set parameters
            $param_user         = $_SESSION['username'];

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: view_all_events.php?action=success");
            } else{
                header("location: view_all_events.php?action=error");
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $isGuestOk = 0; include 'layouts/head.php';?>
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <?php include 'layouts/navbar.php';?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="page-header">
                        <h2>Create Event</h2>
                    </div>

                    <p>Please fill this form and submit to add an event record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="margin-bottom-50">
                        <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $name; ?>" required>
                            <span class="help-block"><?php echo $name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($description_err)) ? 'has-error' : ''; ?>">
                            <label>Description</label>
                            <input type="text" name="description" class="form-control" value="<?php echo $description; ?>" required>
                            <span class="help-block"><?php echo $description_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($slots_err)) ? 'has-error' : ''; ?>">
                            <label>No. of Available Slots</label>
                            <input type="text" name="slots" class="form-control" value="<?php echo $slots; ?>" required>
                            <span class="help-block"><?php echo $slots_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($event_date_err)) ? 'has-error' : ''; ?>">
                            <label>Date of Event</label>
                            <input type="date" name="event_date" class="form-control" value="<?php echo $event_date; ?>" required>
                            <span class="help-block"><?php echo $event_date_err;?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="dashboard.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
    <?php include 'layouts/footer.php';?>
</body>
</html>