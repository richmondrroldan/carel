<!DOCTYPE html>
<html lang="en">
    <head>
        <?php $isGuestOk=0; include 'layouts/head.php';
            // Include Files
            require_once '../classes/config.php';
            require_once '../classes/tools.php';

            $tools = new Tools();

            if($_SESSION['is_admin']){
                $events = $tools->viewAll('events');
            }else {
                $events = $tools->viewAllQry("SELECT * FROM events WHERE created_by='".$_SESSION['username']."'");
            }
        ?>
    </head>
    <body>
        <?php include 'layouts/navbar.php';?>
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1">
                        <?php if(!empty($_GET['action'])):?>
                            <?php if($_GET['action'] == 'success'):?>
                                <div class="alert alert-success">
                                    <p>You have successfully created an event!</p>
                                </div>
                            <?php elseif($_GET['action'] == 'update'):?>
                                <div class="alert alert-success">
                                    <p>You have successfully updated an event!</p>
                                </div>
                            <?php elseif($_GET['action'] == 'delete'):?>
                                <div class="alert alert-success">
                                    <p>You have successfully deleted an event!</p>
                                </div>
                            <?php elseif($_GET['action'] == 'error'):?>
                                <div class="alert alert-danger">
                                    <p>Something went wrong!</p>
                                </div>
                            <?php endif?>
                        <?php else:?>
                            <?php if(!$_SESSION['is_admin']):?>
                            <div class="alert alert-info">
                                <p>Note: Events from other event coordinators shown in the table.</p>
                            </div>
                            <?php endif?> 
                        <?php endif?> 
                        <div class="page-header clearfix">
                            <h2 class="pull-left">View All Events</h2>
                            <a href="create_event.php" class="btn btn-success pull-right">Add New Event</a>
                        </div>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Remaining Slots</th>
                                    <th>Date of Event</th>
                                    <th>Date Created</th>
                                    <th>Created By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($events):?>
                                    <?php foreach($events as $key => $event):?>
                                        <tr>
                                            <td><?= $event['id']?></td>
                                            <td><?= htmlspecialchars($event['name'])?></td>
                                            <td style="width:400px"><?= htmlspecialchars($event['description'])?></td>
                                            <td><?= $event['available_attendees']?></td>
                                            <td><?php echo date('M d, Y',strtotime($event['event_date']));?></td>
                                            <td><?php echo date('M d, Y',strtotime($event['created_at']));?></td>
                                            <td><?= $event['created_by']?></td>
                                            <td>
                                                <a href="read_event.php?id=<?= $event['id']?>" title="View Record" data-toggle="tooltip">
                                                    <span class='glyphicon glyphicon-eye-open'></span>
                                                </a>
                                                <a href="update_event.php?id=<?= $event['id']?>" title="Update Record" data-toggle="tooltip">
                                                    <span class='glyphicon glyphicon-pencil'></span>
                                                </a>
                                                <a href="delete_event.php?id=<?= $event['id']?>" title="Delete Record" data-toggle="tooltip">
                                                    <span class='glyphicon glyphicon-trash'></span>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach;?>
                                <?php else:?>
                                    <tr>
                                        <td colspan="8" class="center">
                                            No records found.
                                        </td>
                                    </tr>
                                <?php endif;?>
                            </tbody>
                        </table>
                    </div>
                </div>        
            </div>
        </div>
        <?php include 'layouts/footer.php';?>
    </body>
</html>