<!DOCTYPE html>
<html lang="en">
<head>
    <?php $isGuestOk=0; include 'layouts/head.php';
    
        // Include Files
        require_once '../classes/config.php';
        require_once '../classes/tools.php';

        $tools = new Tools();

        if($_SESSION['is_admin']){
            $events = count($tools->viewAll('events'));
        }else {
            $events = count($tools->viewAllQry("SELECT * FROM events WHERE created_by='".$_SESSION['username']."'"));
        }

        $users = count($tools->viewAll('users'));

    ?>
   <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <?php include 'layouts/navbar.php';?>
    <div class="container">
        <div class="row">
            <?php if($_SESSION['is_admin']):?>
                <a href="view_all_users.php">
                    <div class="well col-lg-3 center">
                        <h4><i class="fa fa-user"></i> Total Users</h4>
                        <h3><?=$users?></h3>
                    </div>
                </a>
            <?php endif;?>
            <a href="view_all_events.php">
                <div class="well col-lg-3 col-lg-offset-1 center">
                    <h4><i class="fa fa-calendar"></i> Total Events</h4>
                    <h3><?=$events?></h3>
                </div>
            </a>
        </div>
    </div>
    <?php include 'layouts/footer.php';?>
</body>
</html>