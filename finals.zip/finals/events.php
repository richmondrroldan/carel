<?php
    // Include Files
    require_once 'classes/config.php';
    require_once 'classes/tools.php';

    $isGuestOk = 1;

    $tools = new Tools();

    $events = $tools->viewAllQry('SELECT * FROM events where available_attendees > 0');

    // dd($events);
?>
<!doctype html>
<html lang="en">
    <head>
        <?php $isGuestOk = 1; include 'layouts/head.php';?>
    </head>
    <body>

        <!-- HEADER -->
        <header id="events-page">
            <?php include 'layouts/header.php';?>
        </header>










        <!-- BANNER -->
        <section id="events-banner">
            <div class="container">
                <br>
                <div id="subheading">
                    <nav>
                        <ul>
                            <a href="#dance"><li>Dance</li></a>
                            <a href="#exhibit"><li>Exhibit</li></a>
                            <a href="#film"><li>Film</li></a>
                            <a href="#music"><li>Music</li></a>
                            <a href="#talk"><li>Talk</li></a>
                            <a href="#theater"><li>Theater</li></a>
                            <a href="#workshop"><li>Workshop</li></a>
                        </ul>
                    </nav>
                </div>
            </div>
        </section>
    </body>
</html>