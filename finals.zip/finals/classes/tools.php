<?php

function dd($value){
	echo '<pre>'; print_r($value);echo '</pre>';
	exit();
}

class Tools{

    private $connection;
    
    function __construct(){
        global $link;
        $this->connection = $link;
    }

    function __desctruct(){
        // Close connection
        mysqli_close($this->connection);
    }
    
    public function viewAll($tableName){
        $data = array();
        $sql = "SELECT * FROM ".$tableName;
        $result = mysqli_query($this->connection, $sql);
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
                array_push($data, $row);
            }
        }
        return $data;
    }

    public function viewAllQry($sql){
        $data = array();

        $result = mysqli_query($this->connection, $sql);
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
                array_push($data, $row);
            }
        }
        return $data;
    }

    public function view($tableName,$id){ 
        $sql = "SELECT * FROM ".$tableName." WHERE id = ?";

        if($stmt = mysqli_prepare($this->connection, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = trim($id);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
        
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $data = mysqli_fetch_array($result, MYSQLI_ASSOC);               
                }
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
        return $data;
    }

    public function trimAllData()
    {
        foreach ($_POST as $key => $value) {
            $_POST[$key] = trim($_POST[$key]);
        }
    }
}

