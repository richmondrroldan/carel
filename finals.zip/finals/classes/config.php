<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

define( 'DB_SERVER', 'localhost'		, (getenv('WEB_DB_HOST')) ? getenv('WEB_DB_HOST') : 'localhost' );
define( 'DB_NAME', 'finals'		, (getenv('WEB_DB_NAME')) ? getenv('WEB_DB_NAME') : 'finals' );
define( 'DB_USERNAME', 'finals'	, (getenv('WEB_DB_USER')) ? getenv('WEB_DB_USER') : 'finals' );
define( 'DB_PASSWORD', '123456'	, (getenv('WEB_DB_PASS')) ? getenv('WEB_DB_PASS') : '123456' );

/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if($link === false){
    die("ERROR: Could not connect to DB.");
}
?>